public class test
{
    public static void main (String[] args){
		String text = "My ";
		System.out.println("option1: " + text.concat("String"));
		String text2 = new String("My ");
		System.out.println("option2: " + text2+ new String("String"));
		String text3 = "My String";
		String s1 = text3;
		System.out.println("option3: " +   s1);
		String text4 = "My ";
		String s2 = "String";
		text4 = text4 + s2;
		System.out.println("option4: " + text4);
		String mine = "Magdy    Mohamed jab  er elshrief";
		System.out.println(mystery(mine)); 

		String test = new String("%one%%two%%%three%%%%");
		String[] test1 = test.split("%+");
		String[] test2 = test.split("[a-z]+");
		String[] test3 = test.split("one|two|three");
		String[] test4 = test.split("one,two,three");
		Print(test1);
		Print(test2);
		Print(test3);
		Print(test4);
		String s5 = "one (1), two (2), three (3)";
		String[] s6 = s5.split("[^, ]+");
		String[] s7 = s5.split("[^,]+");
		String[] s8 = s5.split("[a-z()0-9]+");
		String[] s9 = s5.split("[a-z]+|[()0-9]+");
		Print(s6);
		Print(s7);
		Print(s8);
		Print(s9);
    }
    public static int mystery(String s)
    {
    	char[] letters = s.toCharArray();
    	int x = 0;
    	for (int i = 0; i < letters.length; i++) {
            if (letters[i] == ' ') {
				letters[i] = '_';
				x++;
            }
        }
    	return x;
    }
    public static void Print(String[] text)
    {
	for(String s:text)
	    System.out.print(s + "_");
	    System.out.println();
    }
}
