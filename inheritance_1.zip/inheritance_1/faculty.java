public class faculty extends Person
{
    private String id;
    private String nameless = this.getName();
    public faculty(){super();}
    public faculty(String name, String id)
    {
	this.nameless = name;
	this.id = id;
	}
    public String getId(){return id;}

    @Override
    public String toString(){return nameless;}
}
