public class Person extends Object
{
    private String name;
    public Person(){super();}
    public String getName(){return name;}
    public void setName(String s){this.name = s;}
    public Person(String name){this.name = name;}
    @Override
    public String toString(){return getName();}
}
