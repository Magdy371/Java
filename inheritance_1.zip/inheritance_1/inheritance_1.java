public class inheritance_1
{
    public static void main(String[] args)
    {
		Person p[] = new Person[3];
        p[0] = new Person("Tim");
		p[1] = new student("magdy" , 1);
		p[2] = new faculty("Mohamed" , "2");
		for(int i=0; i<p.length;i++){
			System.out.println(p[i]);
		}
		Person s = new student("Angg" , 12);
		/*
		this will cause an error as s is refernce for person class
		so we need to use explicit casting
		subclass ref = Superclass superRef
		System.out.println(s.getId());
		we can check if s object is instance of student class
		*/
		if(s instanceof student)
			System.out.println(((student)s).getId());
    }
}
