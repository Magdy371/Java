public class student extends Person
{
    
    private int id;
    private String nameless =this.getName();
    public student()
    {
        super();
        this.setName("Magdy Mohamed Gaber Elshrief");
    }
    public student(String name , int id)
    {
        this.id = id;
        this.nameless = name;
    }
    public int getId(){return id;}
    @Override
    public String toString(){return nameless;}
}
