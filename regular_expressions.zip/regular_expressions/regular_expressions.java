public class regular_expressions{
    public static void main(String[] args) {
        /*
         * A regular expression is a sequence of characters that specifies a match
         * pattern in text.
         * Usually such patterns are used by string-searching algorithms for "find" or
         * "find and replace"
         * operations on strings, or for input validation.
         */
        System.out.println();
        String text = new String("Splitting a string, it's as easy as 1 2 3! Right?");
        System.out.println("The main text is: " + text);
        System.out.println();
        String [] matches ;

        getTokens(text, "i");
        /*
         * 1- Combination method.
         */
        System.out.println("========================================================");
        System.out.println("using regular expression with combination method removing row t's");
        getTokens(text, "t+");
        matches = text.split("[^t]+");
        getMatches(matches);
        System.out.println("========================================================");
        // concatenate method
        System.out.println("Splitting the text using RE Concat i with t");
        getTokens(text, "it");
        matches = text.split("[^it]");
        getMatches(matches);
        System.out.println("========================================================");
        System.out.println("Removing any thing but a->z and 123");
        getTokens(text, "[^a-z123 ]");
        matches = text.split("[a-z123 ]");
        getMatches(matches);
        System.out.println("========================================================");
    }

    /**************************************************************************/
    //print method
    public static void getMatches(String[] matches)
    {
        if (matches.length > 0) {
            System.out.println("Matches are: ");
            for (String match : matches) {
                System.out.print(match + " ");
            }
            System.out.println();
        } else {
            System.out.println("No matches found");
        }
    }
    // get Tokens
    public static void getTokens(String text, String regex) {
        String[] tokens = text.split(regex);
        if (tokens.length > 0) {
            System.out.println("Tokens are: ");
            for (String token : tokens) {
                System.out.print(token + " ");
            }
            System.out.println();
        } else {
            System.out.println("No tokens found");
        }
    }
}
