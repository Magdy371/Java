public class operations {
    public String words;
    public char letter;

    public operations(String w, char l) {
        this.words = w;
        this.letter = l;
    }

    public boolean itHasLetter(operations o) {
        for (char c : o.words.toCharArray()) {
            if (c == o.letter) {
                return true;
            }
        }
        return false;
    }

    public String[] splString(String words) {
        String[] splited = words.split("\\s+");
        return splited;
    }

    public static String replaceCharacter(String words, char l, char repl) {
        char[] cAS = words.toCharArray();
        char[] fW = new char[cAS.length];
        int i = 0;
        for (char c : words.toCharArray()) {
            if (c == l)
                fW[i] = repl;
            else
                fW[i] = c;
            i++;
        }
        return new String(fW);
    }
}
