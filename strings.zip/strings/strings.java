public class strings {
    public static void main(String[] args) {
        String text1 = new String("Hello world!");
        String text2 = "Hello world!";
        String text3 = "Hello world!";
        boolean result1 = text1 == text2;
        boolean result2 = text2 == text3;
        boolean result3 = text1.equals(text2);
        boolean result4 = text2.equals(text3);
        System.out.println("text1 == text2 :" + result1);
        System.out.println("text2 == text3 :" + result2);
        System.out.println("text1.equals(text2) :" + result3);
        System.out.println("text2.equals(text3) :" + result4);
        System.out.println("Hello world!");

        operations o = new operations("Hello world!", 'w');
        System.out.println(" the resultis :" + o.itHasLetter(o));
        if (o.itHasLetter(o)) {
            System.out.println("the word has the letter w and its index is " + o.words.indexOf('w'));
        } else {
            System.out.println("the word does not have the letter" + o.letter);
        }
        String testText = new String("My name    is Magdy Graduated. I am from Egypt");
        System.out.println(testText);
        String[] splited = o.splString(testText);
        for (String s : splited) {
            System.out.println(s);
        }
        System.out.println("the # words in the text is " + splited.length);
        System.out.println(operations.replaceCharacter("a happy", 'a', 'i'));
    }
}
