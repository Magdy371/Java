abstract class abstract_operations
{
	public abstract int getNumOfWords(String text);
	
	public abstract int getNumOfSentences(String text);
	
	public abstract void getSplited_words(String text);
	
	public abstract int getNumOfSyllables(String text);
}